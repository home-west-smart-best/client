var indexSectionsWithContent =
{
  0: "fhpst",
  1: "fpst",
  2: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Pages"
};

