var searchData=
[
  ['switch',['Switch',['../class_switch.html',1,'']]]
];
